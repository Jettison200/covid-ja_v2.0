# Covid Ja | Track What Matters
## This website was created to educate the Jamaican public on the Coronavirus. At a time when there were no websites which focused primarily on Jamaica and it's unique circumstance.
_____________________________________________________________________________________________________________________________

It Was A Successful website with people from all over the world accessing it daily! :)